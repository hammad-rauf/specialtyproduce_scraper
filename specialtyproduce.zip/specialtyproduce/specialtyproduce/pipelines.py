import scrapy
from scrapy.pipelines.images import ImagesPipeline

class SpecialtyproducePipeline(ImagesPipeline):

    def get_media_requests(self, item, info):       

        #for img_url in item['images_url']:
        yield scrapy.Request(item['images_url'], meta={'title': f'{item["title"]}'})

    def file_path(self, request, response=None, info=None):

        return f"{request.meta['title']}.jpg" 