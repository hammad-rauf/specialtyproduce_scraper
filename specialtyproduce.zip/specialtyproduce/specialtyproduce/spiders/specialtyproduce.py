from scrapy import Request
from scrapy.spiders import CrawlSpider, Rule
from scrapy.linkextractors import LinkExtractor

from ..items import SpecialtyproduceItem

#from datetime import date


class SpecialtyProduceSpider(CrawlSpider):

    name = "specialtyproduce"

    img_link = "https:"

    start_urls = [
                "https://www.specialtyproduce.com/"
    ]

    rules = (
        Rule(LinkExtractor(restrict_css=(".element.noShow p a")),callback="specialtyproduce"),  
    )


    def specialtyproduce(self, response):

        products = SpecialtyproduceItem()

        products["title"] = response.css("h1::text").extract_first()

        temp_link = self.img_link
        products["images_url"] = response.css("#picArea img:first-child::attr(src)").extract_first()    
       # products["images_url"] = products["images_url"].replace("//","") 
        products["images_url"] = temp_link + products["images_url"]  


        yield products
 